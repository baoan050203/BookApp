import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tieuthuyet4/main.dart'; // Thay thế tieuthuyet4 bằng tên dự án thực tế của bạn

void main() {
  testWidgets('Login page elements test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(MyApp());

    // Verify that our login page contains the correct elements.
    expect(find.text('Đăng nhập'), findsOneWidget);
    expect(find.text('Tài khoản'), findsOneWidget);
    expect(find.text('Mật Khẩu'), findsOneWidget);
    expect(find.text('ĐĂNG NHẬP'), findsOneWidget);
    expect(find.text('Hoặc'), findsOneWidget);
    expect(find.text('ĐĂNG NHẬP VỚI GOOGLE'), findsOneWidget);
    expect(find.text('ĐĂNG NHẬP VỚI FACEBOOK'), findsOneWidget);
    expect(find.text('ĐĂNG KÝ'), findsOneWidget);
  });
}
