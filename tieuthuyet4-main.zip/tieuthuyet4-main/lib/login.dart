import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[400],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Đăng nhập',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 32),
            const TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Tài khoản',
              ),
            ),
            const SizedBox(height: 16),
            const TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Mật Khẩu',
                suffixIcon: Icon(Icons.visibility),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                // Handle login
              },
              child: const Text('ĐĂNG NHẬP'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[700], // Màu nền của nút
                foregroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: const [
                Expanded(child: Divider()),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text('Hoặc'),
                ),
                Expanded(child: Divider()),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                // Handle Google login
              },
              icon: Image.asset(
                'assets/google_icon.png',
                height: 24,
                width: 24,
              ),
              label: const Text('ĐĂNG NHẬP VỚI GOOGLE'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white, // Màu nền của nút
                foregroundColor: Colors.black, // Màu chữ của nút
                side: const BorderSide(color: Colors.grey), // Màu viền
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                // Handle Facebook login
              },
              icon: Image.asset(
                'assets/facebook_icon.png',
                height: 24,
                width: 24,
              ),
              label: const Text('ĐĂNG NHẬP VỚI FACEBOOK'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white, // Màu nền của nút
                foregroundColor: Colors.black, // Màu chữ của nút
                side: const BorderSide(color: Colors.grey), // Màu viền
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/register');
              },
              child: const Text('ĐĂNG KÝ'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[700], // Màu nền của nút
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
